Video Screensaver, (c) 2012 Michael Barnathan
Licensed under the GPL v3.0; the canonical source tree is at https://svn.barnathan.name/opensource/VideoScreensaver.

Like any screensaver, installing consists of extracting VideoScreensaver.scr into your Windows directory.
In newer versions of Windows you can also right-click the .scr file and select "Install".

Enjoy!
